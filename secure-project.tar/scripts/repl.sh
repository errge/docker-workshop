sudo -u cxuser python3 -i
