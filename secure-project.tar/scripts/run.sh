sudo -u cxuser python3 </var/lib/cxrun/projectfiles/main.py
